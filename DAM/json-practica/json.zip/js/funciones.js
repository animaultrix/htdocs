function leerJSON() {
	var filasFarmacia = "";
	$.ajax({
		type:"GET",
		url: "json/farmacias.json",
		success: function(data) {				
				$.each(data['docs'], function(indice, farmacia){
					filasFarmacia += '<tr>';
					filasFarmacia += '	<td>';
					filasFarmacia += '		'+farmacia.NOMBRE;
					filasFarmacia += '	</td>';
					filasFarmacia += '</tr>';
				});
				$("#filasFarmacia").html(filasFarmacia);
			}, 		
	   dataType: "json"
	});
}